document.addEventListener('DOMContentLoaded', function() {
    fetch('dicas.json')
        .then(response => response.json())
        .then(data => {
            const tipsContainer = document.getElementById('tips');
            data.forEach(tip => {
                const tipElement = document.createElement('div');
                tipElement.className = 'tip';
                tipElement.innerHTML = `
                    <a href="artigo${tip.id}.html">
                        <h2>${tip.title}</h2>
                        <p>${tip.content}</p>
                    </a>
                `;
                tipsContainer.appendChild(tipElement);
            });
        })
        .catch(error => console.error('Erro ao carregar dicas:', error));
});
